# ui-kit

Reusable glass-style UI components for React apps.

## Playground

```bash
npm run playground:dev
```

Open `http://localhost:4177` to preview components and tweak props.

## Install

```bash
npm i @x-happy-x/ui-kit
```

## Usage

```tsx
import { GlassGroup, IconButton, DropdownMenu, DropdownItem } from "@x-happy-x/ui-kit";
import "@x-happy-x/ui-kit/styles.css";
```

## Publish

```bash
export NPM_TOKEN="your_npm_token"
npm run publish:public
```
